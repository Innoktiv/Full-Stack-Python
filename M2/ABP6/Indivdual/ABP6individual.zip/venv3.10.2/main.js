// Module specifier ("@fancyapps/ui") tells the module where to find the module

const myCarousel = new carousel(document.querySelector(".carousel"), {
    // Options
  });